# MonsterMap — protótipo multiplayer local

## Como iniciar
1. Instale Node.js no computador que será o dono do servidor.
2. Abra um terminal nesta pasta.
3. Rode:
   npm install
   node server.js
4. No computador do dono, abra `http://localhost:8080`.
5. Para outro computador na mesma rede, abra `http://IP-DO-DONO:8080`.
6. Todos entram usando o mesmo código de sala.

## O que já funciona
- mapa 2D;
- movimentação com WASD/setas;
- servidor por sala;
- vários jogadores no mesmo mapa;
- cada jogador pode desenhar uma criatura;
- nome, tipo, raridade e stats são gerados;
- criaturas criadas aparecem no mapa;
- outros jogadores podem se aproximar e capturá-las.

## Próximas melhorias
- contas e inventário;
- Pokédex;
- batalhas;
- spawn por regiões;
- sistema de troca;
- salvamento em banco de dados;
- proteção contra duplicação/cheat;
- servidor público na internet;
- geração de stats/descrições por IA;
- editor de desenho mais completo.
