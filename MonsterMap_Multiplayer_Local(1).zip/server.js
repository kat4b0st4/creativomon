const WebSocket = require("ws");
const http = require("http");
const fs = require("fs");

const rooms = new Map();
const server = http.createServer((req,res)=>{
  if(req.url==="/"){res.writeHead(200,{"Content-Type":"text/html; charset=utf-8"});res.end(fs.readFileSync("index.html"))}
  else {res.writeHead(404);res.end("404")}
});
const wss = new WebSocket.Server({server});

function roomData(code){
  if(!rooms.has(code)) rooms.set(code,{players:{},creatures:[]});
  return rooms.get(code);
}
function broadcast(code,msg){
  for(const c of wss.clients){
    if(c.room===code && c.readyState===WebSocket.OPEN)c.send(JSON.stringify(msg));
  }
}
function state(code){
  const r=roomData(code);
  return {type:"state",players:r.players,creatures:r.creatures};
}
wss.on("connection",ws=>{
  ws.on("message",raw=>{
    let m; try{m=JSON.parse(raw)}catch{return}
    if(m.type==="join"){
      ws.room=m.room; ws.id=m.id;
      const r=roomData(m.room);
      r.players[m.id]={id:m.id,x:500,y:300};
      ws.send(JSON.stringify(state(m.room)));
      broadcast(m.room,{type:"chat",text:"👋 "+m.id+" entrou no servidor."});
      broadcast(m.room,state(m.room));
    }
    if(!ws.room)return;
    const r=roomData(ws.room);
    if(m.type==="move" && r.players[m.id]){
      r.players[m.id].x=m.x;r.players[m.id].y=m.y;broadcast(ws.room,state(ws.room));
    }
    if(m.type==="create"){
      const c={...m.creature,id:Math.random().toString(36).slice(2,9),owner:m.id};
      r.creatures.push(c);
      broadcast(ws.room,{type:"chat",text:"✨ "+c.name+" apareceu no mapa!"});
      broadcast(ws.room,state(ws.room));
    }
    if(m.type==="capture"){
      const i=r.creatures.findIndex(c=>c.id===m.creatureId);
      if(i>=0){
        const c=r.creatures[i];r.creatures.splice(i,1);
        broadcast(ws.room,{type:"captured",text:m.id+" capturou "+c.name+"!"});
        broadcast(ws.room,state(ws.room));
      }
    }
  });
  ws.on("close",()=>{
    if(!ws.room)return;
    const r=rooms.get(ws.room);
    if(r){delete r.players[ws.id];broadcast(ws.room,{type:"chat",text:"🚪 "+ws.id+" saiu.");broadcast(ws.room,state(ws.room));}
  });
});
server.listen(8080,()=>console.log("MonsterMap rodando em http://localhost:8080"));
